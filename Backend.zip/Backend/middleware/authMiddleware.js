const jwt = require('jsonwebtoken');
const User = require('../models/User');

const protect = async (req, res, next) => {
  let token;
  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
    try {
      token = req.headers.authorization.split(' ')[1];
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      req.user = await User.findById(decoded.id).select('-password');
      if (!req.user) {
        return res.status(401).json({ message: 'User record no longer exists' });
      }
      return next();
    } catch (error) {
      return res.status(401).json({ message: 'Token unauthorized or expired' });
    }
  }
  if (!token) {
    return res.status(401).json({ message: 'Authorization denied, no token token' });
  }
};

const authorize = (...roles) => {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ message: `Role context (${req.user?.role}) restricted from access` });
    }
    next();
  };
};

module.exports = { protect, authorize };