const express = require('express');
const { submitEntry, getEntries, updateEntryState, deleteEntry } = require('../controllers/entryController');
const { protect, authorize } = require('../middleware/authMiddleware');
const router = express.Router();

router.use(protect);
router.route('/')
  .post(submitEntry)
  .get(getEntries);
router.route('/:id')
  .patch(authorize('Admin'), updateEntryState)
  .delete(authorize('Admin'), deleteEntry);

module.exports = router;