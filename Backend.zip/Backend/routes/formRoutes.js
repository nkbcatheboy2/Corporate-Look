const express = require('express');
const { createForm, getForms, updateForm, deleteForm } = require('../controllers/formController');
const { protect, authorize } = require('../middleware/authMiddleware');
const router = express.Router();

router.use(protect);
router.route('/')
  .post(authorize('Admin'), createForm)
  .get(getForms);
router.route('/:id')
  .put(authorize('Admin'), updateForm)
  .delete(authorize('Admin'), deleteForm);

module.exports = router;