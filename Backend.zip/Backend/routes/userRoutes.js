const express = require('express');
const { getEmployees, createEmployee, updateEmployee, deleteEmployee } = require('../controllers/userController');
const { protect, authorize } = require('../middleware/authMiddleware');
const router = express.Router();

router.use(protect, authorize('Admin'));
router.route('/')
  .get(getEmployees)
  .post(createEmployee);
router.route('/:id')
  .put(updateEmployee)
  .delete(deleteEmployee);

module.exports = router;