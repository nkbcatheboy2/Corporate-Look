const mongoose = require('mongoose');

const FieldConfigSchema = new mongoose.Schema({
  type: { 
    type: String, 
    required: true,
    enum: [
      'text', 'number', 'email', 'password', 'phone', 'url', 'date', 'time',
      'textarea', 'dropdown', 'checkbox', 'radio', 'multiselect', 'toggle'
    ] 
  },
  name: { type: String, required: true }, // camelCase field identity key
  label: { type: String, required: true },
  placeholder: { type: String, default: '' },
  required: { type: Boolean, default: false },
  defaultValue: { type: mongoose.Schema.Types.Mixed, default: '' },
  options: [{ type: String }], // Used for dropdowns, radios, checkboxes, multiselect
  validation: {
    minLength: { type: Number },
    maxLength: { type: Number },
    min: { type: Number },
    max: { type: Number }
  },
  width: { type: String, enum: ['full', 'half'], default: 'full' },
  helpText: { type: String, default: '' }
}, { _id: true });

const FormSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true },
  description: { type: String, default: '' },
  category: { type: String, default: 'General', index: true },
  fields: [FieldConfigSchema],
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true }
}, { timestamps: true });

module.exports = mongoose.model('Form', FormSchema);