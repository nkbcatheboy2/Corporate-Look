const User = require('../models/User');

exports.getEmployees = async (req, res, next) => {
  try {
    const employees = await User.find({ role: 'Employee' }).select('-password').populate('assignedForms', 'title category');
    res.json(employees);
  } catch (error) { next(error); }
};

exports.createEmployee = async (req, res, next) => {
  try {
    const { name, email, password, assignedForms } = req.body;
    const exists = await User.findOne({ email });
    if (exists) return res.status(400).json({ message: 'Identity node registry conflict' });

    const employee = await User.create({ name, email, password, role: 'Employee', assignedForms });
    res.status(201).json(employee);
  } catch (error) { next(error); }
};

exports.updateEmployee = async (req, res, next) => {
  try {
    const { name, email, assignedForms } = req.body;
    const employee = await User.findByIdAndUpdate(req.params.id, { name, email, assignedForms }, { new: true }).select('-password');
    res.json(employee);
  } catch (error) { next(error); }
};

exports.deleteEmployee = async (req, res, next) => {
  try {
    await User.findByIdAndDelete(req.params.id);
    res.json({ message: 'Employee configuration dropped' });
  } catch (error) { next(error); }
};