const Form = require('../models/Form');
const User = require('../models/User');

exports.createForm = async (req, res, next) => {
  try {
    const { title, description, category, fields } = req.body;
    const form = await Form.create({ title, description, category, fields, createdBy: req.user.id });
    res.status(201).json(form);
  } catch (error) { next(error); }
};

exports.getForms = async (req, res, next) => {
  try {
    let query = {};
    if (req.user.role === 'Employee') {
      query = { _id: { $in: req.user.assignedForms } };
    }
    const forms = await Form.find(query).populate('createdBy', 'name email');
    res.json(forms);
  } catch (error) { next(error); }
};

exports.updateForm = async (req, res, next) => {
  try {
    const form = await Form.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!form) return res.status(404).json({ message: 'Form schema identity target not found' });
    res.json(form);
  } catch (error) { next(error); }
};

exports.deleteForm = async (req, res, next) => {
  try {
    const form = await Form.findByIdAndDelete(req.params.id);
    if (!form) return res.status(404).json({ message: 'Form target mapping not found' });
    res.json({ message: 'Form structural model purged' });
  } catch (error) { next(error); }
};