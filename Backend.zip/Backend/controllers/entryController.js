const Entry = require('../models/Entry');
const Form = require('../models/Form');

exports.submitEntry = async (req, res, next) => {
  try {
    const { formId, data } = req.body;
    if (req.user.role === 'Employee' && !req.user.assignedForms.includes(formId)) {
      return res.status(403).json({ message: 'Submission context restricted. Unassigned entity.' });
    }
    const entry = await Entry.create({ form: formId, submittedBy: req.user.id, data });
    res.status(201).json(entry);
  } catch (error) { next(error); }
};

exports.getEntries = async (req, res, next) => {
  try {
    let query = {};
    if (req.user.role === 'Employee') {
      query.submittedBy = req.user.id;
    }
    if (req.query.status) query.status = req.query.status;
    if (req.query.formId) query.form = req.query.formId;

    const entries = await Entry.find(query)
      .populate('form', 'title category fields')
      .populate('submittedBy', 'name email')
      .sort({ createdAt: -1 });
    res.json(entries);
  } catch (error) { next(error); }
};

exports.updateEntryState = async (req, res, next) => {
  try {
    const { status, rejectionReason } = req.body;
    const entry = await Entry.findById(req.params.id);
    if (!entry) return res.status(404).json({ message: 'Entry transaction reference not found' });

    entry.status = status;
    if (rejectionReason) entry.rejectionReason = rejectionReason;
    entry.reviewedBy = req.user.id;
    entry.reviewedAt = new Date();

    await entry.save();
    res.json(entry);
  } catch (error) { next(error); }
};

exports.deleteEntry = async (req, res, next) => {
  try {
    const entry = await Entry.findByIdAndDelete(req.params.id);
    if (!entry) return res.status(404).json({ message: 'Entry target identifier not found' });
    res.json({ message: 'Entry cleared permanently' });
  } catch (error) { next(error); }
};